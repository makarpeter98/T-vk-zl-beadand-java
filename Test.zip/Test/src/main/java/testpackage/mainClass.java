/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testpackage;

import javax.swing.JFrame;

/**
 *
 * @author hallgato
 */
public class mainClass {
    
    
    
    public static void main(String[] args) throws InterruptedException
    {
        SingUpPanel mainPanel = new SingUpPanel();
        System.out.println("Hello World!");
        JFrame frame = new JFrame("some title"); // creates the frame
        frame.add(mainPanel);
        frame.setSize(500,300);
        frame.setResizable(false);
        frame.setVisible(true);
        Thread.sleep(8000);
        frame.setVisible(false);
        
    }
}
